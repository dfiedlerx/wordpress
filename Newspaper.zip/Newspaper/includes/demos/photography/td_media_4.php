<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/photography/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/photography/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p5',                  "http://demo_content.tagdiv.com/Newspaper_6/photography/p5.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p6',                  "http://demo_content.tagdiv.com/Newspaper_6/photography/p6.jpg");


